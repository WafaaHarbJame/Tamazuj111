package com.verbosetech.yoohoo.interfaces;

/**
 * Created by a_man on 31-12-2017.
 */

public interface UserGroupSelectionDismissListener {
    void onUserGroupSelectDialogDismiss();

    void selectionDismissed();
}
